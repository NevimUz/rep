
const express = require("express");
const request = require("request");
var bodyParser = require('body-parser')

const app = express();

var urlencodedParser = bodyParser.urlencoded({ extended: false });

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

app.post('/', urlencodedParser, function(req, res) {
    console.log(req.body.city);
    let city = req.body.city;
    request(
        `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=133a27fe437d86f966b4a0be1e069e3b`,
        function (error, response, body) {
            if (response.statusCode === 200) {
                let data = JSON.parse(body);
                res.send(`Počasí ve městě "${city}" je ${data.weather[0]['description']}`);
                

            }
        }

    );
    
  });

function Req(string){
    request(
        `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=133a27fe437d86f966b4a0be1e069e3b`,
        function (error, response, body) {
            if (response.statusCode === 200) {
                let data = JSON.parse(body);
                res.send(`Počasí ve městě "${city}" je ${data.weather[0]['description']}`);
                

            }
        }

    );
}

app.listen(3000, () => console.log('port 3000'));