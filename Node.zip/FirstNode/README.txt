1. zapnout server pres prikaz: node server.js
2.program posloucha na portu 3000 tim padem do vyhledavace napsat loclahost:3000
3.napsat anglicky nazev mesta treba London a weather API napise jake je tam pocasi.